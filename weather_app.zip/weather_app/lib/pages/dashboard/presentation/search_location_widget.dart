import 'package:flutter/material.dart';

class SearchLocationWidget extends StatelessWidget {
  const SearchLocationWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return TextField(controller: TextEditingController(),);
  }
}

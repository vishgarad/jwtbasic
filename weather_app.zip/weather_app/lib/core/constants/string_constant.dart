class StringConstants{
  static const String tempFarenh = '\u2109';
  static const String humidity = '\u0026 ';
}
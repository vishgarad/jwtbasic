class HttpConstants{

  static const String apiKey = '8c5fc0c43ed143dd8c193257231306';
  static const String baseUrl = 'api.weatherapi.com/v1/';
  static const String searchLocation = '/v1/search.json';
  static const String currentWeather = '/v1/current.json';
  static const String historyWeather = '/v1/history.json';

}